"use strict";(()=>{var e={};e.id=914,e.ids=[914],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3254:(e,a,r)=>{r.r(a),r.d(a,{originalPathname:()=>c,patchFetch:()=>h,requestAsyncStorage:()=>k,routeModule:()=>d,serverHooks:()=>v,staticGenerationAsyncStorage:()=>o});var t={};r.r(t),r.d(t,{POST:()=>m});var n=r(9303),i=r(8716),s=r(670),f=r(7070),x=r(4672),l=r(8129),u=r(6555);async function g(e,a,r,t,n,i="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",s,f,x){let{systemInstruction:l,userPrompt:g}=function(e,a,r,t,n,i,s,f,x){let l=e.title.split(" gegn "),u=l[0]?.trim()||"Stefnandi",g=l[1]?.trim()||"Stefndi",m=`\xde\xfa ert s\xe9rh\xe6f\xf0ur d\xf3mst\xf3lal\xf6gma\xf0ur og r\xe9ttarfarsfr\xe6\xf0ingur \xed \xedslensku d\xf3mskerfi (ILCMS).
Verkefni \xfeitt er a\xf0 semja fullb\xfain, formlega gallalaus og r\xf6kstudd dr\xf6g a\xf0 ${"stefna"===a?"STEFNU":"GREINARGER\xd0"} fyrir ${i||"H\xe9ra\xf0sd\xf3m Reykjav\xedkur"} samkv\xe6mt l\xf6gum um me\xf0fer\xf0 einkam\xe1la nr. 91/1991.

Mikilv\xe6gar reglur um \xedslenska skjalager\xf0 fyrir d\xf3mst\xf3la:
1. Nota\xf0u sta\xf0la\xf0a uppbyggingu \xedslenskra d\xf3msskjala:
   - D\xd3MST\xd3LL OG M\xc1LSN\xdaMER \xcd HAUS
   - A\xd0ILAR OG M\xc1LFLYTJENDUR
   - I. D\xd3MKR\xd6FUR (A\xf0alkr\xf6fur, varakr\xf6fur, vextir og dr\xe1ttarvextir skv. l\xf6gum nr. 38/2001, m\xe1lskostna\xf0ur skv. 130. gr. laga nr. 91/1991)
   - II. M\xc1LSATVIK (Heildst\xe6\xf0, t\xedmar\xf6\xf0u\xf0 m\xe1lsatvikal\xfdsing bygg\xf0 \xe1 fyrirliggjandi m\xe1lsskj\xf6lum og l\xfdsingu)
   - III. M\xc1LS\xc1ST\xc6\xd0UR OG LAGAR\xd6K (N\xe1kv\xe6m l\xf6gfr\xe6\xf0ileg r\xf6ksemdaf\xe6rsla sem fl\xe9ttar saman \xf6ll tilgreind laga\xe1kv\xe6\xf0i og d\xf3maford\xe6mi vi\xf0 atvik m\xe1lsins)
   - IV. S\xd6NNUNARG\xd6GN OG SKJALASKR\xc1 (N\xfameru\xf0 skr\xe1 yfir framl\xf6g\xf0 skj\xf6l og v\xe6ntanlega vitnalei\xf0slu)
   - V. R\xc9TTARFAR (Varnar\xfeing, stefnufrestur/greinarger\xf0arfrestur, birting, m\xe1lsh\xe6fi)
   - DAGSETNING OG UNDIRSKRIFT L\xd6GMANNS
2. Textinn skal vera \xe1 vanda\xf0ri, formfastri l\xf6gfr\xe6\xf0i\xedslensku.
3. Nota\xf0u n\xe1kv\xe6mlega \xfeau g\xf6gn, laga\xe1kv\xe6\xf0i og ford\xe6mi sem eru l\xf6g\xf0 fram \xed fyrirspurninni.`,d=r.length>0?r.map(e=>`• ${e.act_name} nr. ${e.act_number}, ${e.article} (${e.title}):
  „${e.text}“`).join("\n\n"):"Engin s\xe9rst\xf6k laga\xe1kv\xe6\xf0i valin.",k=t.length>0?t.map(e=>`• ${e.case_reference} (${e.court}, ${e.date}) - ${e.parties}:
  \xdatdr\xe1ttur: ${e.summary}
  Ni\xf0ursta\xf0a: ${e.key_findings}`).join("\n\n"):"Engin s\xe9rst\xf6k d\xf3maford\xe6mi valin.",o=n.length>0?n.map((e,a)=>`[M\xe1lsskjal ${a+1}] ${e.title} (${e.doc_type}, ${e.page_count} bls.):
${e.summary||e.content?.slice(0,600)||""}`).join("\n\n"):"Engin s\xe9rst\xf6k m\xe1lsskj\xf6l tilgreind.";return{systemInstruction:m,userPrompt:`Vinsamlegast semdu heildst\xe6\xf0 og l\xf6gfr\xe6\xf0ilega v\xf6ndu\xf0 dr\xf6g a\xf0 ${"stefna"===a?"STEFNU":"GREINARGER\xd0"}:

D\xd3MST\xd3LL: ${i||"H\xe9ra\xf0sd\xf3mur Reykjav\xedkur"}
M\xc1LSN\xdaMER: ${e.case_number}
HEITI M\xc1LS: ${e.title}
STEFNANDI: ${u}
STEFNDI: ${g}
L\xddSING: ${e.description}
${s?`FJ\xc1RH\xc6\xd0ARKRAFA: ${s}`:""}
${f?`S\xc9RST\xd6K KR\xd6FUGER\xd0: ${f}`:""}
${x?`LEI\xd0BEININGAR L\xd6GMANNS: ${x}`:""}

VALIN LAGA\xc1KV\xc6\xd0I:
${d}

VALIN D\xd3MAFORD\xc6MI:
${k}

M\xc1LSSKJ\xd6L \xcd M\xc1LINU:
${o}`}}(e,a,r,t,n,i,s,f,x);try{let s=await u.g.chat([{role:"system",content:l},{role:"user",content:g}]);if(s.isRealInference&&s.text?.trim()?.length>200){let f=s.text.trim(),x=f.split(/\s+/).filter(Boolean).length;return{title:`${"stefna"===a?"Stefna":"Greinarger\xf0"} \xed m\xe1li ${e.case_number} (${e.title})`,doc_type:a,content:f,summary:`Sta\xf0bundi\xf0 Ollama-skjal a\xf0 ${a} \xed m\xe1li ${e.case_number}.`,court_name:i,generated_at:new Date().toISOString(),model_used:s.modelUsed||"ollama-legal-gemma",inference_source:"ollama_airgap",stats:{statutes_count:r.length,precedents_count:t.length,documents_count:n.length,word_count:x},sections:{header:"\xcd H\xc9RA\xd0SD\xd3MI REYKJAV\xcdKUR",claims:"I. D\xd3MKR\xd6FUR",facts:"II. M\xc1LSATVIK",legal_grounds:"III. M\xc1LS\xc1ST\xc6\xd0UR OG LAGAR\xd6K",evidence:"IV. S\xd6NNUNARG\xd6GN",procedure:"V. R\xc9TTARFAR"}}}}catch(e){console.warn("[Draft API] Ollama call error, proceeding to local rules engine:",e?.message||e)}return function(e,a,r,t,n,i="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",s,f,x){let l=e.title.split(" gegn "),u=l[0]?.trim()||"Stefnandi",g=l[1]?.trim()||"Stefndi",m=new Date().toLocaleDateString("is-IS",{year:"numeric",month:"long",day:"numeric"}),d=s||("case-01"===e.id?"kr. 48.500.000":"case-02"===e.id?"kr. 21.400.000":"case-03"===e.id?"kr. 14.200.000":"case-04"===e.id?"kr. 35.800.000":"case-05"===e.id?"kr. 18.600.000":"kr. 10.000.000"),k=`\xcd H\xc9RA\xd0SD\xd3MI REYKJAV\xcdKUR
D\xf3m\xfeing h\xe1\xf0 \xed D\xf3mh\xfasinu vi\xf0 L\xe6kjartorg

M\xe1l nr. ${e.case_number}

${u}
(kt. 010185-2349)
a\xf0 heimilisfangi Reykjav\xedk
M\xe1lflytjandi: Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.

gegn

${g}
(kt. 540269-0129)
a\xf0 heimilisfangi Reykjav\xedk
M\xe1lflytjandi: T\xf3mas Gunnarsson hdl.

================================================================================
                               ${"stefna"===a?"S T E F N A":"G R E I N A R G E R \xd0"}
================================================================================`,o="";o="stefna"===a?`I. D\xd3MKR\xd6FUR STEFNANDA

Stefnandi gerir eftirfarandi d\xf3mkr\xf6fur \xed m\xe1linu:

1. A\xf0alkrafa:
   A\xf0 stefndi, ${g}, ver\xf0i me\xf0 d\xf3mi d\xe6mdur til a\xf0 grei\xf0a stefnanda, ${u}, fj\xe1rh\xe6\xf0 a\xf0 upph\xe6\xf0 ${d}, \xe1samt v\xf6xtum skv. 8. gr. laga nr. 38/2001 um vexti og dr\xe1ttarvexti fr\xe1 kr\xf6fudegi og dr\xe1ttarv\xf6xtum skv. 1. mgr. 6. gr., sbr. 9. gr. s\xf6mu laga fr\xe1 birtingardegi stefnu \xfeessarar til grei\xf0sludags.

2. Varakrafa:
   Til vara er \xfeess krafist a\xf0 stefndi ver\xf0i d\xe6mdur til grei\xf0slu ska\xf0ab\xf3ta e\xf0a afsl\xe1ttar eftir mati og sanngirnis\xfarlausn d\xf3msins me\xf0 s\xf6mu v\xf6xtum og dr\xe1ttarv\xf6xtum og greinir \xed a\xf0alkr\xf6fu.

3. M\xe1lskostna\xf0arkrafa:
   A\xf0 stefndi ver\xf0i d\xe6mdur til a\xf0 grei\xf0a stefnanda m\xe1lskostna\xf0 a\xf0 ska\xf0lausu samkv\xe6mt framl\xf6g\xf0um m\xe1lskostna\xf0arreikningi m\xe1lflytjanda stefnanda, sbr. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la, \xe1samt vir\xf0isaukaskatti skv. l\xf6gum nr. 50/1988.
${f?`
S\xe9rst\xf6k vi\xf0b\xf3tarkrafa stefnanda:
${f}`:""}`:`I. D\xd3MKR\xd6FUR STEFNDA

Stefndi gerir eftirfarandi d\xf3mkr\xf6fur \xed m\xe1linu:

1. A\xf0alkrafa:
   A\xf0 stefndi, ${g}, ver\xf0i s\xfdkna\xf0ur af \xf6llum kr\xf6fum stefnanda, ${u}, \xed m\xe1li \xfeessu.

2. Varakrafa (til fr\xe1v\xedsunar):
   Til vara er \xfeess krafist a\xf0 m\xe1li \xfeessu ver\xf0i v\xedsa\xf0 fr\xe1 d\xf3mi vegna vanefnda \xe1 l\xf6gbundnum stefnufresti skv. 80. gr. laga nr. 91/1991 e\xf0a \xf3fulln\xe6gjandi m\xe1latilb\xfana\xf0ar skv. 80. og 96. gr. s\xf6mu laga.

3. \xderautavarakrafa:
   Til \xferautavara a\xf0 grei\xf0slur stefnda ver\xf0i st\xf3rlega l\xe6kka\xf0ar me\xf0 tilliti til eigin sakar stefnanda e\xf0a \xf3fyrirs\xe9\xf0ra samningsatvika.

4. M\xe1lskostna\xf0arkrafa:
   A\xf0 stefnandi ver\xf0i d\xe6mdur til a\xf0 grei\xf0a stefnda fullan m\xe1lskostna\xf0 skv. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la, \xe1samt vir\xf0isaukaskatti.
${f?`
S\xe9rstakar varnarkr\xf6fur stefnda:
${f}`:""}`;let v=n.map((e,a)=>`   (${a+1}) Skv. m\xe1lsskjali „${e.title}“ (${e.doc_type}): ${e.summary||"Sta\xf0festing \xe1 efnis\xfe\xe1ttum m\xe1lsins."}`).join("\n"),c=`II. M\xc1LSATVIK

${e.description}

M\xe1lsatvik eru n\xe1nar rakin \xed eftirfarandi m\xe1lsskj\xf6lum sem l\xf6g\xf0 eru fram til stu\xf0nings m\xe1linu:
${v||"   M\xe1lsatvik sty\xf0jast vi\xf0 framl\xf6g\xf0 g\xf6gn a\xf0ila og m\xe1lskj\xf6l \xed d\xf3maskjalaskr\xe1."}

A\xf0ilar \xe1ttu \xed l\xf6gm\xe6tu og bindandi samningssambandi. \xc1greiningur s\xe1 sem h\xe9r liggur fyrir d\xf3mst\xf3lum var\xf0ar vanefndir \xe1 samningsbundnum og l\xf6gm\xe6ltum skyldum. Stefnandi sendi t\xedmanlegar skriflegar a\xf0finnslur og tilkynningar um lei\xf0 og forsendur l\xe1gu fyrir. Stefndi hefur engu a\xf0 s\xed\xf0ur neita\xf0 a\xf0 efna skyldur s\xednar e\xf0a b\xe6ta fyrir tj\xf3ni\xf0 me\xf0 fulln\xe6gjandi h\xe6tti, sem gerir d\xf3mst\xf3lame\xf0fer\xf0 \xf3umfl\xfdjanlega.
${x?`
\xc1r\xe9tting l\xf6gmanns um m\xe1lsatvik:
${x}`:""}`,h=r.length>0?r.map(e=>`• ${e.act_name} nr. ${e.act_number} — ${e.article} (${e.title}):
  Samkv\xe6mt \xe1kv\xe6\xf0inu: „${e.text}“
  \xc1kv\xe6\xf0i \xfeetta hefur beina \xfe\xfd\xf0ingu \xed m\xe1linu. \xdea\xf0 rennir \xf3tv\xedr\xe6\xf0um lagasto\xf0um undir r\xe9ttarst\xf6\xf0u a\xf0ila og sty\xf0ur ${"stefna"===a?"kr\xf6fuger\xf0 stefnanda um full efndab\xf3t og l\xf6gvar\xf0a hagsmuni":"varnir stefnda um s\xfdknu og fr\xe1v\xedsun m\xe1lsins"}.`).join("\n\n"):`• L\xf6g um me\xf0fer\xf0 einkam\xe1la nr. 91/1991:
  Byggt er \xe1 almennum meginreglum einkam\xe1lar\xe9ttar um s\xf6nnunarbyr\xf0i, m\xe1lsh\xe6fi og r\xe9ttarfarslega hagsmuni.`,p=t.length>0?`

Til stu\xf0nings er s\xe9rstaklega v\xedsa\xf0 til eftirfarandi d\xf3maford\xe6ma:
`+t.map(e=>`• ${e.case_reference} (${e.court}, ${e.date}):
  \xcd d\xf3minum komst r\xe9tturinn a\xf0 \xfeeirri ni\xf0urst\xf6\xf0u a\xf0: „${e.key_findings}“.`).join("\n\n"):"",y=`III. M\xc1LS\xc1ST\xc6\xd0UR OG LAGAR\xd6K

Kr\xf6fur ${"stefna"===a?"stefnanda":"stefnda"} \xed m\xe1li \xfeessu byggjast \xe1 gildandi \xedslenskum l\xf6gum, formfestum r\xe9ttarheimildum og vi\xf0urkenndri d\xf3mvenju H\xe6star\xe9ttar og Landsr\xe9ttar.

L\xf6ggilt laga\xe1kv\xe6\xf0i sem reynir \xe1 \xed m\xe1linu:
${h}${p}

Krafa um vexti og dr\xe1ttarvexti sty\xf0st vi\xf0 8. og 9. gr. laga nr. 38/2001 um vexti og dr\xe1ttarvexti.
Krafa um m\xe1lskostna\xf0 er studd 1. mgr. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la, enda hefur rekstur m\xe1ls \xfeessa haft \xed f\xf6r me\xf0 s\xe9r umtalsver\xf0an kostna\xf0 vegna l\xf6gfr\xe6\xf0ia\xf0sto\xf0ar og gagna\xf6flunar.`,_=n.map((e,a)=>`   Skjal nr. ${a+1}: „${e.title}“ (${e.doc_type}, ${e.page_count} bls.) — Var\xf0ar: ${e.summary||"S\xf6nnun \xe1 m\xe1lsatvikum"}.`).join("\n"),$=`IV. S\xd6NNUNARG\xd6GN OG SKJALASKR\xc1

${"stefna"===a?"Stefnandi":"Stefndi"} leggur fram eftirfarandi m\xe1lsskj\xf6l til s\xf6nnunar \xe1 m\xe1ls\xe1st\xe6\xf0um s\xednum \xed samr\xe6mi vi\xf0 101. gr. laga nr. 91/1991:

${_||"   1. Skrifleg samningsg\xf6gn og tilkynningar a\xf0ila.\n   2. Framl\xf6g\xf0 vottor\xf0 og sko\xf0unarsk\xfdrslur s\xe9rfr\xe6\xf0inga."}

\xde\xe1 \xe1skilur m\xe1lsa\xf0ili s\xe9r r\xe9tt til a\xf0 leggja fram vi\xf0b\xf3targ\xf6gn, lei\xf0a vitni fyrir d\xf3m og krefjast d\xf3mkvaddra matsmanna ef \xfe\xf6rf krefur vi\xf0 rekstur m\xe1lsins.`,S="";S="stefna"===a?`V. R\xc9TTARFAR OG STEFNUFRESTUR

M\xe1l \xfeetta er h\xf6f\xf0a\xf0 fyrir ${i||"H\xe9ra\xf0sd\xf3mi Reykjav\xedkur"} \xe1 grundvelli almennra reglna um varnar\xfeing skv. 24. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la.

Stefnufrestur er \xe1kve\xf0inn \xed samr\xe6mi vi\xf0 80. gr. laga nr. 91/1991 og skal vera minnst 3 s\xf3larhringar ef stefndi hefur b\xfasetu \xed sama d\xf3mumd\xe6mi, en 14 s\xf3larhringar ef b\xfaseta er utan d\xf3mumd\xe6mis.

Stefndi er h\xe9r me\xf0 l\xf6glega kalla\xf0ur til a\xf0 m\xe6ta fyrir d\xf3m\xfeingi ${i||"H\xe9ra\xf0sd\xf3ms Reykjav\xedkur"} sem h\xe1\xf0 ver\xf0ur \xed D\xf3mh\xfasinu vi\xf0 L\xe6kjartorg, til a\xf0 hl\xfd\xf0a \xe1 d\xf3mkr\xf6fur stefnanda, leggja fram varnir og g\xf6gn.

S\xe9rstaklega er vakin athygli stefnda \xe1 \xfev\xed a\xf0 m\xe6ti hann ekki vi\xf0 \xfeingfestingu m\xe1lsins e\xf0a l\xe1ti ekki l\xf6gm\xe6tan umbo\xf0smann s\xe6kja \xfeing, m\xe1 kve\xf0a upp \xfativistard\xf3m samkv\xe6mt kr\xf6fum stefnanda skv. 1. mgr. 113. gr. laga nr. 91/1991.`:`V. R\xc9TTARFAR OG FRESTIR

Greinarger\xf0 \xfeessi er l\xf6g\xf0 fram \xed samr\xe6mi vi\xf0 97. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la innan \xfeess frests sem d\xf3mari veitti vi\xf0 \xfeingfestingu m\xe1lsins.

Stefndi andm\xe6lir \xf6llum kr\xf6fum stefnanda sem \xf3r\xf6kstuddum og \xf3s\xf6nnu\xf0um og krefst \xfeess a\xf0 frestur ver\xf0i veittur til frekari gagna\xf6flunar skv. 101. gr. s\xf6mu laga.`;let j=`${k}

${o}

${c}

${y}

${$}

${S}

Reykjav\xedk, ${m}

Vir\xf0ingarfyllst,
Fyrir h\xf6nd ${"stefna"===a?u:g},

___________________________________________
${"stefna"===a?"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.":"T\xf3mas Gunnarsson hdl."}
L\xf6gma\xf0ur / M\xe1lflytjandi`,R=j.split(/\s+/).filter(Boolean).length;return{title:`${"stefna"===a?"Stefna":"Greinarger\xf0"} \xed m\xe1li ${e.case_number} (${e.title})`,doc_type:a,content:j,summary:`Sj\xe1lfvirk skjalager\xf0: Dr\xf6g a\xf0 ${a} \xed m\xe1li ${e.case_number} bygg\xf0 \xe1 ${r.length} v\xf6ldum laga\xe1kv\xe6\xf0um, ${t.length} d\xf3maford\xe6mum og ${n.length} m\xe1lsskj\xf6lum.`,court_name:i,generated_at:new Date().toISOString(),model_used:"icelandic-legal-rules-engine",inference_source:"local_rules_engine",stats:{statutes_count:r.length,precedents_count:t.length,documents_count:n.length,word_count:R},sections:{header:k,claims:o,facts:c,legal_grounds:y,evidence:$,procedure:S}}}(e,a,r,t,n,i,s,f,x)}async function m(e){try{let{case_id:a,doc_type:r="stefna",selected_statute_ids:t=[],selected_precedent_ids:n=[],selected_doc_ids:i=[],court_name:s="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",claim_amount:u,custom_claims:m,lawyer_notes:d}=await e.json(),k=x.Bb.find(e=>e.id===a)||x.Bb[0];if(!k)return f.NextResponse.json({error:"M\xe1l fannst ekki \xed kerfinu."},{status:404});let o=x.qM.filter(e=>e.case_id===k.id),v=i&&i.length>0?o.filter(e=>i.includes(e.id)):o,c=[];c=t&&t.length>0?l.d.filter(e=>t.includes(e.id)):"stefna"===r?l.d.filter(e=>["statute-em-80","statute-em-130","statute-vx-8-9"].includes(e.id)):l.d.filter(e=>["statute-em-97","statute-em-130"].includes(e.id));let h=[];n&&n.length>0?h=l.A.filter(e=>n.includes(e.id)):"case-01"===k.id?h=l.A.filter(e=>["prec-hrd-58-2020","prec-hrd-412-2019"].includes(e.id)):"case-03"===k.id&&(h=l.A.filter(e=>["prec-hrd-120-2021"].includes(e.id)));let p=await g(k,r,c,h,v,s,u,m,d);return f.NextResponse.json(p)}catch(e){return console.error("[Legal Draft API Error]:",e),f.NextResponse.json({error:"Villa kom upp vi\xf0 sj\xe1lfvirka skjalager\xf0: "+(e?.message||e)},{status:500})}}let d=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/v1/ai/draft/route",pathname:"/api/v1/ai/draft",filename:"route",bundlePath:"app/api/v1/ai/draft/route"},resolvedPagePath:"/app/applet/src/app/api/v1/ai/draft/route.ts",nextConfigOutput:"standalone",userland:t}),{requestAsyncStorage:k,staticGenerationAsyncStorage:o,serverHooks:v}=d,c="/api/v1/ai/draft/route";function h(){return(0,s.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:o})}},8129:(e,a,r)=>{r.d(a,{A:()=>n,d:()=>t});let t=[{id:"statute-em-80",act_name:"L\xf6g um me\xf0fer\xf0 einkam\xe1la",act_number:"91/1991",article:"80. gr.",title:"Stefnufrestur",text:"Stefnufrestur skal vera minnst 3 s\xf3larhringar ef stefndi hefur b\xfasetu e\xf0a dvalarsta\xf0 \xed sama d\xf3mumd\xe6mi og d\xf3m\xfeing er h\xe1\xf0. Ef stefndi b\xfdr annars sta\xf0ar \xe1 landinu skal fresturinn vera minnst 14 s\xf3larhringar. Ef hann b\xfdr \xed Evr\xf3pu skal fresturinn vera minnst einn m\xe1nu\xf0ur en 3 m\xe1nu\xf0ir ef hann b\xfdr utan Evr\xf3pu. Stefnufrestur telst fr\xe1 birtingu stefnu til \xfeingfestingardags.",keywords:["stefnufrestur","birting","\xfeingfesting","d\xf3mumd\xe6mi","80. gr.","frestur"]},{id:"statute-em-81",act_name:"L\xf6g um me\xf0fer\xf0 einkam\xe1la",act_number:"91/1991",article:"81. gr.",title:"D\xf3mhl\xe9",text:"D\xf3mhl\xe9 eru fr\xe1 15. j\xfal\xed til 15. \xe1g\xfast og fr\xe1 20. desember til 5. jan\xfaar, svo og dymbilviku og p\xe1skaviku. \xcd d\xf3mhl\xe9um l\xed\xf0a stefnufrestir ekki nema stefnandi krefjist \xfeess s\xe9rstaklega e\xf0a l\xf6g kve\xf0i s\xe9rstaklega \xe1 um anna\xf0. Ef frestur \xe1 a\xf0 renna \xfat \xed d\xf3mhl\xe9i framlengist hann til fyrsta virka dags a\xf0 d\xf3mhl\xe9i loknu.",keywords:["d\xf3mhl\xe9","sumarfr\xed","j\xf3l","p\xe1skar","stefnufrestur","frestur","81. gr."]},{id:"statute-em-97",act_name:"L\xf6g um me\xf0fer\xf0 einkam\xe1la",act_number:"91/1991",article:"97. gr.",title:"Greinarger\xf0 stefnda",text:"Vi\xf0 \xfeingfestingu m\xe1ls skal d\xf3mari gefa stefnda h\xe6filegan frest til a\xf0 leggja fram greinarger\xf0, venjulega ekki lengri en 3 til 4 vikur, nema s\xe9rstakar \xe1st\xe6\xf0ur m\xe6li me\xf0 \xf6\xf0ru. Ef stefndi s\xe6kir ekki \xfeing e\xf0a skilar ekki greinarger\xf0 innan frests m\xe1 kve\xf0a upp \xfativistard\xf3m skv. kr\xf6fum stefnanda.",keywords:["greinarger\xf0","frestur","\xfeingfesting","\xfativistard\xf3mur","stefndi","97. gr."]},{id:"statute-em-101",act_name:"L\xf6g um me\xf0fer\xf0 einkam\xe1la",act_number:"91/1991",article:"101. gr.",title:"Gagna\xf6flun og m\xe1latilb\xfana\xf0ur",text:"Eftir framlagningu greinarger\xf0ar \xe1kve\xf0ur d\xf3mari frest til gagna\xf6flunar. A\xf0ilar skulu leggja fram \xf6ll skrifleg s\xf6nnunarg\xf6gn og tilgreina vitni sem \xf3ska\xf0 er eftir a\xf0 lei\xf0a fyrir d\xf3m. S\xe9 \xf3ska\xf0 eftir d\xf3mkvaddri matsger\xf0 skal \xfea\xf0 gert \xe1n \xe1st\xe6\xf0ulauss dr\xe1ttar.",keywords:["gagna\xf6flun","matsger\xf0","s\xf6nnunarg\xf6gn","vitni","101. gr."]},{id:"statute-em-115",act_name:"L\xf6g um me\xf0fer\xf0 einkam\xe1la",act_number:"91/1991",article:"115. gr.",title:"D\xf3msuppkva\xf0ning",text:"D\xf3mur skal kve\xf0inn upp svo flj\xf3tt sem au\xf0i\xf0 er eftir a\xf0 m\xe1l er d\xf3mteki\xf0 og eigi s\xed\xf0ar en innan 4 vikna. Ef s\xe9rstaklega stendur \xe1 m\xe1 fresturinn vera allt a\xf0 6 vikum en \xfe\xe1 skal b\xf3ka s\xe9rstaklega um \xe1st\xe6\xf0ur dr\xe1ttar.",keywords:["d\xf3msuppkva\xf0ning","d\xf3mur","frestur","d\xf3mteki\xf0","115. gr."]},{id:"statute-fk-17",act_name:"L\xf6g um fasteignakaup",act_number:"40/2002",article:"17. gr.",title:"Galli \xe1 fasteign",text:"Fasteign telst g\xf6llu\xf0 ef h\xfan svarar ekki til \xfeeirra krafna sem lei\xf0a af samningi a\xf0ila e\xf0a \xe1kv\xe6\xf0um laga \xfeessara. Fasteign telst einnig g\xf6llu\xf0 ef h\xfan er \xed verulega verra \xe1standi en kaupandi haf\xf0i \xe1st\xe6\xf0u til a\xf0 \xe6tla mi\xf0a\xf0 vi\xf0 kaupver\xf0 og aldur hennar.",keywords:["fasteignakaup","galli","leyndur galli","mygla","17. gr."]},{id:"statute-fk-27",act_name:"L\xf6g um fasteignakaup",act_number:"40/2002",article:"27. gr.",title:"Tilkynning um galla (A\xf0finnslufrestur)",text:"Kaupandi glatar r\xe9tti til a\xf0 bera fyrir sig galla ef hann tilkynnir seljanda ekki um hann \xe1n \xe1st\xe6\xf0ulauss dr\xe1ttar eftir a\xf0 hann var\xf0 hans var e\xf0a m\xe1tti ver\xf0a hans var vi\xf0 venjulega athugun. Tilkynning ver\xf0ur \xfe\xf3 alltaf a\xf0 berast \xed s\xed\xf0asta lagi innan 5 \xe1ra fr\xe1 \xfev\xed a\xf0 kaupandi veitti fasteign vi\xf0t\xf6ku.",keywords:["tilkynningarfrestur","a\xf0finnslufrestur","fasteignakaup","v\xe1n","27. gr."]}],n=[{id:"prec-hrd-120-2021",case_reference:"Hrd. 120/2021",court:"H\xe6stir\xe9ttur \xcdslands",date:"2021-11-04",parties:"Kaupendur gegn Seljendum einb\xfdlish\xfass",summary:"M\xe1l var\xf0a\xf0i leyndan rakagalla og myglu \xed \xfatveggjum og loftpl\xf6tum einb\xfdlish\xfass. Kaupendur l\xe9tu gera faglega \xfattekt og tilkynntu seljanda um galla 2 m\xe1nu\xf0um eftir sko\xf0un s\xe9rfr\xe6\xf0ings.",key_findings:"H\xe6stir\xe9ttur sta\xf0festi a\xf0 tilkynning innan 2 m\xe1na\xf0a fr\xe1 \xfev\xed a\xf0 fagleg matsger\xf0 l\xe1 fyrir teldist ger\xf0 \xe1n \xe1st\xe6\xf0ulauss dr\xe1ttar skv. 27. gr. laga nr. 40/2002. Kaupendum d\xe6mdur afsl\xe1ttur a\xf0 fj\xe1rh\xe6\xf0 8,5 millj\xf3nir kr\xf3na.",statutory_basis:["27. gr. laga nr. 40/2002","17. gr. laga nr. 40/2002"]},{id:"prec-lr-45-2023",case_reference:"Landsr\xe9ttur 45/2023",court:"Landsr\xe9ttur",date:"2023-03-15",parties:"A gegn B ehf.",summary:"\xc1fr\xfdja\xf0 \xfarskur\xf0i h\xe9ra\xf0sd\xf3ms um fr\xe1v\xedsun m\xe1ls \xfear sem stefna var birt stefnda \xe1 Akureyri a\xf0eins 8 s\xf3larhringum fyrir \xfeingfestingu \xed H\xe9ra\xf0sd\xf3mi Reykjav\xedkur.",key_findings:"Landsr\xe9ttur sta\xf0festi fr\xe1v\xedsun m\xe1lsins. L\xf6gbundinn 14 s\xf3larhringa stefnufrestur skv. 80. gr. laga nr. 91/1991 \xfeegar stefndi er me\xf0 b\xfasetu utan d\xf3mumd\xe6mis er \xf3fr\xe1v\xedkjanleg r\xe9ttarfarsregla til verndar varnara\xf0ila.",statutory_basis:["80. gr. laga nr. 91/1991","81. gr. laga nr. 91/1991"]},{id:"prec-hrd-412-2019",case_reference:"Hrd. 412/2019",court:"H\xe6stir\xe9ttur \xcdslands",date:"2019-10-10",parties:"Fyrrverandi framkv\xe6mdastj\xf3ri gegn T\xe6knilausnum hf.",summary:"Fyrirvaralaus riftun r\xe1\xf0ningarsamnings vegna meintra tr\xfana\xf0arbrota starfsmanns.",key_findings:"H\xe6stir\xe9ttur taldi f\xe9laginu ekki hafa tekist a\xf0 sanna verulegar e\xf0a \xe1setningslegar vanefndir sem r\xe9ttl\xe6ttu riftun. F\xe9laginu var gert a\xf0 grei\xf0a laun \xfat samningsbundinn 6 m\xe1na\xf0a uppsagnarfrest \xe1samt miskab\xf3tum.",statutory_basis:["L\xf6g nr. 19/1979","Samningal\xf6g nr. 7/1936"]},{id:"prec-hrd-58-2020",case_reference:"Hrd. 58/2020",court:"H\xe6stir\xe9ttur \xcdslands",date:"2020-04-23",parties:"Byggingarf\xe9lag X ehf. gegn Verkkaupa Y",summary:"\xc1greiningur um lokauppgj\xf6r verksamnings og dagsektir vegna tafa vi\xf0 afhendingu fj\xf6lb\xfdlish\xfass.",key_findings:"Verkkaupi glata\xf0i r\xe9tti til dagsekta a\xf0 hluta \xfear sem hann haf\xf0i ekki svara\xf0 t\xedmanlega tilkynningum verktaka um tafir af v\xf6ldum h\xf6nnunarbreytinga.",statutory_basis:["\xcdST 30:2012","Samningal\xf6g nr. 7/1936"]}]},6555:(e,a,r)=>{r.d(a,{g:()=>n});class t{constructor(){this.baseUrl=process.env.OLLAMA_BASE_URL||"http://127.0.0.1:11434",this.defaultModel=process.env.OLLAMA_MODEL||"gemma2:9b"}getBaseUrl(){return this.baseUrl}getDefaultModel(){return this.defaultModel}async checkHealth(){try{let e=new AbortController,a=setTimeout(()=>e.abort(),2e3),r=await fetch(`${this.baseUrl}/api/tags`,{signal:e.signal});if(clearTimeout(a),!r.ok)return{healthy:!1,models:[],error:`HTTP ${r.status}`};let t=((await r.json()).models||[]).map(e=>e.name||e.model);return{healthy:!0,models:t}}catch(e){return{healthy:!1,models:[],error:e.message||"Ollama service unavailable or starting up"}}}async chat(e,a){let r=a||this.defaultModel,t=async a=>{try{let r=new AbortController,t=setTimeout(()=>r.abort(),18e3),n=await fetch(`${this.baseUrl}/api/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:a,messages:e,stream:!1,options:{temperature:.2,top_p:.9}}),signal:r.signal});if(clearTimeout(t),n.ok){let e=await n.json(),r=e?.message?.content||"";if(r.trim())return{text:r,modelUsed:a,isRealInference:!0}}}catch(e){}return null},n=await t(r);if(n)return n;try{let e=await this.checkHealth();if(e.healthy&&e.models.length>0){let a=e.models.find(e=>e.toLowerCase().includes("gemma"))||e.models[0];if(a&&a!==r){let e=await t(a);if(e)return e}}}catch{}return{text:"",modelUsed:r,isRealInference:!1}}}let n=new t}};var a=require("../../../../../webpack-runtime.js");a.C(e);var r=e=>a(a.s=e),t=a.X(0,[276,972,672],()=>r(3254));module.exports=t})();