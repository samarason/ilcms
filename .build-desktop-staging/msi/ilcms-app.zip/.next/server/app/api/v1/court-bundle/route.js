"use strict";(()=>{var e={};e.id=237,e.ids=[237],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},186:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>$,patchFetch:()=>b,requestAsyncStorage:()=>x,routeModule:()=>m,serverHooks:()=>c,staticGenerationAsyncStorage:()=>g});var n={};a.r(n),a.d(n,{GET:()=>p,POST:()=>f});var r=a(9303),s=a(8716),i=a(670),l=a(7070),o=a(4672);function u(e,t,a){let n=1,r=t.map((e,t)=>{let a=e.page_count||1,r=n,s=n+a-1;n=s+1;let i="Lagt fram til s\xf6nnunar \xe1 m\xe1lsatvikum.";return"Stefna"===e.doc_type&&(i="Kr\xf6fuger\xf0, m\xe1ls\xe1st\xe6\xf0ur og l\xf6gvar\xf0ir hagsmunir stefnanda."),"Samningur"===e.doc_type&&(i="S\xf6nnun \xe1 samningssambandi og samningsskyldum a\xf0ila."),("Matsger\xf0"===e.doc_type||"S\xe9rfr\xe6\xf0isk\xfdrsla"===e.doc_type)&&(i="S\xe9rfr\xe6\xf0ilegt mat \xe1 tj\xf3ni, g\xf6llum og orsakasamhengi."),{id:e.id,number:t+1,title:e.title,category:e.doc_type||"Almennt m\xe1lsskjal",date:e.created_at.split("T")[0],startPage:r,endPage:s,pageCount:a,relevance:i}});return{caseNumber:e.case_number,courtName:a?.courtName||"H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",actionType:"Einkam\xe1l",plaintiff:a?.plaintiff||{name:e.title.split(" gegn ")[0]||"Stefnandi",idNumber:"540269-0129",attorney:"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",role:"stefnandi"},defendant:a?.defendant||{name:e.title.split(" gegn ")[1]||"Stefndi",idNumber:"620104-3380",attorney:"T\xf3mas Gunnarsson hdl.",role:"stefndi"},compilationDate:new Date().toISOString().split("T")[0],totalExhibits:r.length,totalPages:Math.max(1,n-1),exhibits:r,...a}}function d(e){let t="=".repeat(78),a="-".repeat(78),n=`
${t}
                   D\xd3MASKJALASKR\xc1 FYRIR H\xc9RA\xd0SD\xd3MI
${t}
D\xf3mst\xf3ll:      ${e.courtName}
M\xe1lsn\xfamer:     ${e.caseNumber}
Tegund m\xe1ls:   ${e.actionType}

Stefnandi:     ${e.plaintiff.name} (kt. ${e.plaintiff.idNumber})
M\xe1lflytjandi:  ${e.plaintiff.attorney}

Stefndi:       ${e.defendant.name} (kt. ${e.defendant.idNumber})
M\xe1lflytjandi:  ${e.defendant.attorney}

Fr\xe1gangsdags:  ${e.compilationDate}
Samtals:       ${e.totalExhibits} m\xe1lsskj\xf6l | ${e.totalPages} bla\xf0s\xed\xf0ur
${t}

NR.  HEITI M\xc1LSSKJALS                           BLS.         S\xd6NNUNAR\xde\xdd\xd0ING
${a}`,r=e.exhibits.map(e=>{let t=String(e.number).padStart(2,"0"),a=e.title.padEnd(42," ").slice(0,42),n=`bls. ${e.startPage}–${e.endPage}`.padEnd(12," ");return`${t}   ${a} ${n} ${e.relevance}`}).join("\n"),s=`
${a}
M\xe1lsgagnasafn \xfeetta er fr\xe1gengi\xf0 samkv\xe6mt reglum d\xf3mst\xf3las\xfdslunnar um fr\xe1gang
og framlagningu m\xe1lsgagna \xed einkam\xe1lum fyrir h\xe9ra\xf0sd\xf3mst\xf3lum.
${t}
`;return`${n}
${r}
${s}`}async function p(e){try{let{searchParams:t}=new URL(e.url),a=t.get("case_id"),n=t.get("format")||"json";if(!a)return l.NextResponse.json({error:"M\xe1lsn\xfamer vantar (case_id)"},{status:400});let r=o.Bb.find(e=>e.id===a);if(!r)return l.NextResponse.json({error:"M\xe1l fannst ekki"},{status:404});let s=o.qM.filter(e=>e.case_id===a),i=u(r,s),p=d(i);if("text"===n)return new l.NextResponse(p,{headers:{"Content-Type":"text/plain; charset=utf-8","Content-Disposition":`attachment; filename="domaskjalaskra-${r.case_number.replace(/[^a-zA-Z0-9]/g,"_")}.txt"`}});return l.NextResponse.json({bundle:i,formattedText:p,total_exhibits:i.totalExhibits,total_pages:i.totalPages})}catch(e){return l.NextResponse.json({error:"Villa vi\xf0 ger\xf0 m\xe1lsgagnasafns"},{status:500})}}async function f(e){try{let{case_id:t,overrides:a}=await e.json();if(!t)return l.NextResponse.json({error:"case_id vantar"},{status:400});let n=o.Bb.find(e=>e.id===t);if(!n)return l.NextResponse.json({error:"M\xe1l fannst ekki"},{status:404});let r=o.qM.filter(e=>e.case_id===t),s=u(n,r,a),i=d(s);return l.NextResponse.json({bundle:s,formattedText:i})}catch(e){return l.NextResponse.json({error:"Villa vi\xf0 uppf\xe6rslu m\xe1lsgagnasafns"},{status:500})}}let m=new r.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/v1/court-bundle/route",pathname:"/api/v1/court-bundle",filename:"route",bundlePath:"app/api/v1/court-bundle/route"},resolvedPagePath:"/app/applet/src/app/api/v1/court-bundle/route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:x,staticGenerationAsyncStorage:g,serverHooks:c}=m,$="/api/v1/court-bundle/route";function b(){return(0,i.patchFetch)({serverHooks:c,staticGenerationAsyncStorage:g})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),n=t.X(0,[276,972,672],()=>a(186));module.exports=n})();