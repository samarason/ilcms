"use strict";(()=>{var e={};e.id=482,e.ids=[482],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},5397:(e,t,i)=>{i.r(t),i.d(t,{originalPathname:()=>x,patchFetch:()=>p,requestAsyncStorage:()=>g,routeModule:()=>c,serverHooks:()=>m,staticGenerationAsyncStorage:()=>f});var a={};i.r(a),i.d(a,{GET:()=>u,POST:()=>_});var n=i(9303),r=i(8716),s=i(670),d=i(7070),o=i(4672),l=i(2276);async function u(e,{params:t}){try{let{id:e}=await t;if(!o.Bb.find(t=>t.id===e))return d.NextResponse.json({error:"M\xe1l fannst ekki."},{status:404});let i=o.bn.filter(t=>t.case_id===e);return d.NextResponse.json({success:!0,invoices:i.sort((e,t)=>new Date(t.created_at).getTime()-new Date(e.created_at).getTime())})}catch(e){return console.error("Error fetching invoices:",e),d.NextResponse.json({error:"Gat ekki s\xf3tt reikninga: "+e?.message},{status:500})}}async function _(e,{params:t}){try{let{id:i}=await t,a=o.Bb.find(e=>e.id===i);if(!a)return d.NextResponse.json({error:"M\xe1l fannst ekki."},{status:404});let n=await e.json(),r=n.client_name||(a.title.includes(" gegn ")?a.title.split(" gegn ")[0]:"Umbj\xf3\xf0andi"),s=n.client_kennitala||"",u=n.client_address||"",_=n.attorney_name||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",c=n.law_firm_name||"L\xf6gmenn L\xe6kjarg\xf6tu slf.",g=n.law_firm_kennitala||"540209-1120",f=n.law_firm_vat_no||"102345",m=n.law_firm_bank||"0101-26-045678",x=new Date,p=n.issue_date||x.toISOString().split("T")[0],v=new Date(x);v.setDate(v.getDate()+14);let S=n.due_date||v.toISOString().split("T")[0],$=new Date(x);$.setDate($.getDate()+30);let k=n.penalty_date||$.toISOString().split("T")[0],I=n.status||"issued",y=[];if(n.line_items&&Array.isArray(n.line_items)&&n.line_items.length>0)y=n.line_items;else{if(n.time_ids&&Array.isArray(n.time_ids))for(let e of o.zo.filter(e=>e.case_id===i&&n.time_ids.includes(e.id))){let t=e.duration_minutes/60,i=Math.round(t*e.hourly_rate),a=Math.round(.24*i);y.push({id:`inv-li-${Date.now()}-${e.id}`,type:"time",ref_id:e.id,description:`${e.description} (${t.toFixed(1)} klst. \xe1 kr. ${e.hourly_rate.toLocaleString("is-IS")})`,quantity:t,unit_price:e.hourly_rate,vat_rate:.24,amount_ex_vat:i,vat_amount:a,total_inc_vat:i+a})}if(n.expense_ids&&Array.isArray(n.expense_ids))for(let e of o.gp.filter(e=>e.case_id===i&&n.expense_ids.includes(e.id))){let t=e.vat_amount||0;y.push({id:`inv-li-${Date.now()}-${e.id}`,type:"expense",ref_id:e.id,description:`${e.title}${e.receipt_doc_title?` [Fskj.: ${e.receipt_doc_title}]`:""}`,quantity:1,unit_price:e.amount,vat_rate:e.vat_rate,amount_ex_vat:e.amount,vat_amount:t,total_inc_vat:e.amount+t})}}if(0===y.length)return d.NextResponse.json({error:"Reikningur ver\xf0ur a\xf0 innihalda a\xf0 minnsta kosti einn li\xf0."},{status:400});let R=y.reduce((e,t)=>e+t.amount_ex_vat,0),h=y.reduce((e,t)=>e+t.vat_amount,0),w=R+h,L=(0,o.f2)(i,o._z).currentBalance,N=Number(n.retainer_deducted||0);N>L&&(N=L),N>w&&(N=w);let D=Math.max(0,w-N),E=new Date().getFullYear(),b=(o.bn.filter(e=>e.invoice_number.startsWith(`REIK-${E}`)).length+1).toString().padStart(4,"0"),G=`REIK-${E}-${b}`,A={id:`inv-${Date.now()}`,invoice_number:G,case_id:i,case_number:a.case_number,case_title:a.title,client_name:r,client_kennitala:s||void 0,client_address:u||void 0,attorney_name:_,law_firm_name:c,law_firm_kennitala:g,law_firm_vat_no:f,law_firm_bank:m,issue_date:p,due_date:S,penalty_date:k,status:I,line_items:y,subtotal_ex_vat:R,total_vat:h,total_inc_vat:w,retainer_deducted:N,final_amount_due:D,notes:n.notes||void 0,payment_date:"paid"===I?p:void 0,payment_reference:"paid"===I?"Greitt vi\xf0 \xfatg\xe1fu":void 0,created_at:new Date().toISOString()};o.bn.unshift(A);let T=y.filter(e=>"time"===e.type&&e.ref_id).map(e=>e.ref_id);for(let e of o.zo)T.includes(e.id)&&(e.status="invoiced");let j=y.filter(e=>"expense"===e.type&&e.ref_id).map(e=>e.ref_id);for(let e of o.gp)j.includes(e.id)&&(e.status="invoiced");if(N>0){let e={id:`ret-deduct-${Date.now()}`,case_id:i,type:"deduction",amount:N,date:p,payment_method:"bank_transfer",reference:`R\xe1\xf0st\xf6fun \xe1 reikning ${G}`,invoice_id:A.id,invoice_number:G,notes:`Fr\xe1dr\xe1ttur af tryggingaf\xe9 vegna reiknings nr. ${G}.`,created_at:new Date().toISOString()};o._z.unshift(e)}let M=(0,l.t)(A),K={id:`doc-inv-${Date.now()}`,case_id:i,title:`Reikningur ${G} (${r}).txt`,doc_type:"Reikningur",status:"READY",page_count:1,created_at:new Date().toISOString(),filing_date:p,author:_,summary:`\xdatgefinn reikningur nr. ${G}. Upph\xe6\xf0 kr. ${w.toLocaleString("is-IS")} m. VSK${N>0?` (\xfear af dregi\xf0 tryggingaf\xe9 kr. ${N.toLocaleString("is-IS")}, eftirst\xf6\xf0var kr. ${D.toLocaleString("is-IS")})`:""}.`,content:M,version:1,versions:[{id:`v-inv-${Date.now()}`,version_number:1,created_at:new Date().toISOString(),author:_,change_summary:"Reikningur f\xe6r\xf0ur \xed m\xe1lasafn",title:`Reikningur ${G}.txt`,content:M,page_count:1}]};return o.qM.unshift(K),d.NextResponse.json({success:!0,message:`Reikningur ${G} var \xfatb\xfainn me\xf0 g\xf3\xf0um \xe1rangri.`,invoice:A,document:K,updated_retainer_balance:(0,o.f2)(i,o._z).currentBalance})}catch(e){return console.error("Error creating invoice:",e),d.NextResponse.json({error:"Gat ekki b\xfai\xf0 til reikning: "+e?.message},{status:500})}}let c=new n.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/api/v1/cases/[id]/invoices/route",pathname:"/api/v1/cases/[id]/invoices",filename:"route",bundlePath:"app/api/v1/cases/[id]/invoices/route"},resolvedPagePath:"/app/applet/src/app/api/v1/cases/[id]/invoices/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:g,staticGenerationAsyncStorage:f,serverHooks:m}=c,x="/api/v1/cases/[id]/invoices/route";function p(){return(0,s.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:f})}},2276:(e,t,i)=>{i.d(t,{t:()=>a});function a(e){let t="=".repeat(78),i="-".repeat(78),a={draft:"DR\xd6G",issued:"\xdaTGEFI\xd0",paid:"GREITT",cancelled:"\xd3GILT / FELLT NI\xd0UR"}[e.status]||e.status.toUpperCase(),n="";return n+=`${t}
                          REIKNINGUR / INVOICE
                           [ ${a} ]
${t}

\xdaTGEFANDI (L\xd6GMANNSSTOFA):
Nafn:          ${e.law_firm_name||"L\xf6gmenn L\xe6kjarg\xf6tu slf."}
Kennitala:     ${e.law_firm_kennitala||"540209-1120"}
VSK-n\xfamer:     ${e.law_firm_vat_no||"102345"}
M\xe1lflytjandi:  ${e.attorney_name||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl."}
Bankareikn.:   ${e.law_firm_bank||"0101-26-045678"}

GREI\xd0ANDI (UMBJ\xd3\xd0ANDI):
Nafn:          ${e.client_name}
`,e.client_kennitala&&(n+=`Kennitala:     ${e.client_kennitala}
`),e.client_address&&(n+=`Heimilisfang:  ${e.client_address}
`),n+=`M\xe1lsn\xfamer:     ${e.case_number} - ${e.case_title}

REIKNINGSUPPL\xddSINGAR:
Reikningsnr.:  ${e.invoice_number}
\xdatg\xe1fudagur:   ${e.issue_date}
Gjalddagi:     ${e.due_date}
Eindagi:       ${e.penalty_date}
`,e.payment_date&&(n+=`Grei\xf0sludagur: ${e.payment_date} (${e.payment_reference||"Grei\xf0sla m\xf3ttekin"})
`),n+=`
${i}
SUNDURLI\xd0UN REIKNINGS
${i}
L\xddSING / VERK\xde\xc1TTUR                  MAGN     EIN.VER\xd0     VSK%    SAMTALS M. VSK
${i}
`,e.line_items&&0!==e.line_items.length?e.line_items.forEach((e,t)=>{let i=String(t+1).padStart(2," "),a=e.description.length>34?e.description.slice(0,31)+"...":e.description.padEnd(34," "),r=e.quantity.toFixed(1).padStart(5," "),s=`${e.unit_price.toLocaleString("is-IS")} kr.`.padStart(11," "),d=`${Math.round(100*e.vat_rate)}%`.padStart(5," "),o=`${e.total_inc_vat.toLocaleString("is-IS")} kr.`.padStart(14," ");n+=`${i}. ${a} ${r} ${s} ${d} ${o}
`}):n+=`Engir li\xf0ir \xe1 reikningi.
`,n+=`${i}
Samtals \xe1n vir\xf0isaukaskatts:                              kr. ${e.subtotal_ex_vat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur samtals (24% / 0% VSK):                 kr. ${e.total_vat.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARFJ\xc1RH\xc6\xd0 M. VSK:                                    kr. ${e.total_inc_vat.toLocaleString("is-IS")}
`,e.retainer_deducted>0&&(n+=`Fr\xe1dr\xe1ttur af tryggingaf\xe9 (v\xf6rslureikningi):            - kr. ${e.retainer_deducted.toLocaleString("is-IS")}
------------------------------------------------------------------------------
EFTIRST\xd6\xd0VAR TIL GREI\xd0SLU:                                kr. ${e.final_amount_due.toLocaleString("is-IS")}
`),e.notes&&(n+=`
Athugasemdir:
${e.notes}
`),n+=`
${t}
GREI\xd0SLUSKILM\xc1LAR:
Vinsamlegast leggi\xf0 inn \xe1 ofangreindan reikning og tilgreini\xf0 reikningsn\xfamer sem tilv\xedsun.
S\xe9 reikningur ekki greiddur \xe1 eindaga reiknast h\xe6stu l\xf6gleyf\xf0u dr\xe1ttarvextir
samkv\xe6mt 1. mgr. 6. gr. laga nr. 38/2001 um vexti og ver\xf0tryggingu fr\xe1 gjalddaga.
${t}
`}}};var t=require("../../../../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[276,972,672],()=>i(5397));module.exports=a})();