"use strict";(()=>{var e={};e.id=328,e.ids=[328],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},1480:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>S,patchFetch:()=>p,requestAsyncStorage:()=>g,routeModule:()=>c,serverHooks:()=>f,staticGenerationAsyncStorage:()=>m});var r={};a.r(r),a.d(r,{GET:()=>x,POST:()=>u});var n=a(9303),i=a(8716),s=a(670),o=a(7070),l=a(4672),d=a(7616);async function x(e,{params:t}){try{let{id:a}=await t,r=l.Bb.find(e=>e.id===a);if(!r)return o.NextResponse.json({error:"M\xe1l fannst ekki."},{status:404});let{searchParams:n}=new URL(e.url),i=n.get("attorney")||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",s=n.get("party")||void 0,x=n.get("court")||"H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",u=n.get("judge")||void 0,c=n.get("partyRole")||"Stefnandi",g="true"===n.get("clientVatDeductible"),m="false"!==n.get("includeInterestClaim"),f=n.get("additionalRemarks")||void 0,S=n.get("timeIds"),p=n.get("expIds"),k=l.zo.filter(e=>e.case_id===a),$=l.gp.filter(e=>e.case_id===a);if(S){let e=S.split(",");k=k.filter(t=>e.includes(t.id))}if(p){let e=p.split(",");$=$.filter(t=>e.includes(t.id))}let I=(0,d.T)(k,$),y=(0,d.x)(r,k,$,{attorneyName:i,partyName:s,courtName:x,judgeName:u,partyRole:c,clientVatDeductible:g,includeInterestClaim:m,additionalRemarks:f});return o.NextResponse.json({case:r,summary:I,formatted_text:y,time_entries:k,expenses:$})}catch(e){return console.error("Error generating cost statement:",e),o.NextResponse.json({error:"Gat ekki \xfatb\xfai\xf0 m\xe1lskostna\xf0aryfirlit: "+e?.message},{status:500})}}async function u(e,{params:t}){try{let{id:a}=await t,r=l.Bb.find(e=>e.id===a);if(!r)return o.NextResponse.json({error:"M\xe1l fannst ekki."},{status:404});let n=await e.json().catch(()=>({})),i=n.attorney||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",s=n.party||void 0,x=n.court||"H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",u=n.judge||void 0,c=n.partyRole||"Stefnandi",g=!!n.clientVatDeductible,m=!1!==n.includeInterestClaim,f=n.additionalRemarks||void 0,S=l.zo.filter(e=>e.case_id===a),p=l.gp.filter(e=>e.case_id===a);n.timeIds&&Array.isArray(n.timeIds)&&(S=S.filter(e=>n.timeIds.includes(e.id))),n.expIds&&Array.isArray(n.expIds)&&(p=p.filter(e=>n.expIds.includes(e.id)));let k=(0,d.T)(S,p),$=(0,d.x)(r,S,p,{attorneyName:i,partyName:s,courtName:x,judgeName:u,partyRole:c,clientVatDeductible:g,includeInterestClaim:m,additionalRemarks:f}),I=g?k.legalFeeExVat:k.legalFeeIncVat,y=g?k.courtFees+k.otherExpensesExVat:k.totalExpensesIncVat,v=`M\xe1lskostna\xf0aryfirlit (${x}) - ${r.case_number} (${new Date().toISOString().split("T")[0]}).txt`,N={id:`doc-cost-${Date.now()}`,case_id:a,title:v,doc_type:"M\xe1lskostna\xf0aryfirlit",status:"READY",page_count:Math.max(1,Math.ceil($.split("\n").length/45)),created_at:new Date().toISOString(),filing_date:new Date().toISOString().split("T")[0],author:i,summary:`M\xe1lskostna\xf0arkrafa kr. ${(I+y).toLocaleString("is-IS")} (${g?"\xe1n VSK":"m. VSK"}). \xde\xf3knun kr. ${I.toLocaleString("is-IS")} (${k.billableHours} klst.) + gj\xf6ld kr. ${y.toLocaleString("is-IS")}.`,content:$,notes:`\xdatb\xfai\xf0 skv. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la til framlagningar fyrir ${x}.${u?` D\xf3mari: ${u}.`:""}`,notes_updated_at:new Date().toISOString(),version:1,versions:[{id:`v-cost-${Date.now()}-1`,version_number:1,created_at:new Date().toISOString(),author:i,change_summary:`Formlegt m\xe1lskostna\xf0aryfirlit lagt fram fyrir ${x}`,title:v,content:$,page_count:Math.max(1,Math.ceil($.split("\n").length/45))}]};return l.qM.unshift(N),o.NextResponse.json({success:!0,message:"M\xe1lskostna\xf0aryfirlit vista\xf0 \xed m\xe1lasafn",document:N,summary:k})}catch(e){return console.error("Error saving cost statement as document:",e),o.NextResponse.json({error:"Gat ekki vista\xf0 m\xe1lskostna\xf0aryfirlit: "+e?.message},{status:500})}}let c=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/v1/cases/[id]/cost-statement/route",pathname:"/api/v1/cases/[id]/cost-statement",filename:"route",bundlePath:"app/api/v1/cases/[id]/cost-statement/route"},resolvedPagePath:"/app/applet/src/app/api/v1/cases/[id]/cost-statement/route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:m,serverHooks:f}=c,S="/api/v1/cases/[id]/cost-statement/route";function p(){return(0,s.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:m})}},7616:(e,t,a)=>{a.d(t,{T:()=>n,x:()=>i});var r=a(4672);function n(e,t){let a=0,r=0,n=0;e.forEach(e=>{if(a+=e.duration_minutes,e.is_billable){r+=e.duration_minutes;let t=e.duration_minutes/60;n+=Math.round(t*e.hourly_rate)}});let i=Math.round(.24*n),s=n+i,o=0,l=0,d=0;t.forEach(e=>{"court_fee"===e.expense_type?o+=e.amount:(l+=e.amount,d+=e.vat_amount||(e.vat_rate?Math.round(e.amount*e.vat_rate):0))});let x=o+l+d;return{totalMinutes:a,totalHours:Number((a/60).toFixed(2)),billableMinutes:r,billableHours:Number((r/60).toFixed(2)),legalFeeExVat:n,legalFeeVat:i,legalFeeIncVat:s,courtFees:o,otherExpensesExVat:l,otherExpensesVat:d,totalExpensesIncVat:x,grandTotalClaim:s+x,vatRate:.24}}function i(e,t,a,i="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",s){let o,l,d;let x=n(t,a),u=new Date().toLocaleDateString("is-IS",{year:"numeric",month:"long",day:"numeric"}),c="=".repeat(78),g="-".repeat(78),m="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",f="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",S=s,p="Stefnandi",k=!1,$=!0;"object"==typeof i&&null!==i?(i.attorneyName&&(m=`${i.attorneyName}${i.attorneyTitle?` ${i.attorneyTitle}`:""}`),i.courtName&&(f=i.courtName),i.judgeName&&(o=i.judgeName),i.partyName&&(S=i.partyName),i.partyRole&&(p=i.partyRole),void 0!==i.clientVatDeductible&&(k=i.clientVatDeductible),void 0!==i.includeInterestClaim&&($=i.includeInterestClaim),i.interestText&&(l=i.interestText),i.additionalRemarks&&(d=i.additionalRemarks)):"string"==typeof i&&(m=i);let I=S||(e.title.includes(" gegn ")?e.title.split(" gegn ")[0]:"Stefnandi"),y=k?x.legalFeeExVat:x.legalFeeIncVat,v=k?x.courtFees+x.otherExpensesExVat:x.totalExpensesIncVat,N=y+v,R="";R+=`${c}
                M\xc1LSKOSTNA\xd0ARYFIRLIT FYRIR H\xc9RA\xd0SD\xd3MI
               (skv. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la)
${c}

D\xf3mst\xf3ll:      ${f}${o?` (D\xf3mari: ${o})`:""}
M\xe1lsn\xfamer:     ${e.case_number}
M\xe1lsa\xf0ilar:    ${e.title}
A\xf0ili:         ${I} (${p})
M\xe1lflytjandi:  ${m}
Dagsetning:    ${u}

${g}
I. SUNDURLI\xd0UN \xc1 L\xd6GMANNS\xde\xd3KNUN (VINNUSTUNDIR)
${g}
DAGS.        KLST.  T\xcdMAGJALD    VERK\xde\xc1TTUR OG L\xddSING \xc1 L\xd6GFR\xc6\xd0IST\xd6RFUM
${g}
`;let L=t.filter(e=>e.is_billable);return 0===L.length?R+=`Engir t\xedmali\xf0ir skr\xe1\xf0ir.
`:L.forEach(e=>{let t=(e.duration_minutes/60).toFixed(1).padStart(4," "),a=`${e.hourly_rate.toLocaleString("is-IS")} kr.`.padStart(11," "),n=r.lf[e.task_category]||e.task_category;R+=`${e.date}  ${t}  ${a}  [${n}]
                          ${e.description} (${e.user_name})
`}),R+=`
${g}
Samtals unnar stundir m\xe1lflytjanda:       ${x.billableHours.toLocaleString("is-IS")} klst.
L\xf6gmanns\xfe\xf3knun alls \xe1n VSK:               kr. ${x.legalFeeExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur (24% VSK):              kr. ${x.legalFeeVat.toLocaleString("is-IS")}
L\xd6GMANNS\xde\xd3KNUN SAMTALS M. VSK:            kr. ${x.legalFeeIncVat.toLocaleString("is-IS")}

${g}
II. \xdaTLAG\xd0UR KOSTNA\xd0UR OG D\xd3MGJ\xd6LD
${g}
DAGS.        UPPH\xc6\xd0         LI\xd0UR / TEGUND
${g}
`,0===a.length?R+=`Enginn \xfatlag\xf0ur kostna\xf0ur skr\xe1\xf0ur.
`:a.forEach(e=>{let t=r.v6[e.expense_type]||e.expense_type,a=e.amount+(e.vat_amount||0),n=`${a.toLocaleString("is-IS")} kr.`.padStart(12," ");R+=`${e.incurred_date}  ${n}  ${e.title} (${t})
`}),R+=`
${g}
D\xf3mgj\xf6ld skv. l\xf6gum nr. 88/1991 (0% VSK):  kr. ${x.courtFees.toLocaleString("is-IS")}
Annar \xfatlag\xf0ur kostna\xf0ur \xe1n VSK:          kr. ${x.otherExpensesExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur af \xfatl\xf6g\xf0um kostna\xf0i:   kr. ${x.otherExpensesVat.toLocaleString("is-IS")}
\xdaTLAG\xd0UR KOSTNA\xd0UR SAMTALS:               kr. ${x.totalExpensesIncVat.toLocaleString("is-IS")}

${c}
III. HEILDARKRAFA UM M\xc1LSKOSTNA\xd0
${c}
`,k?R+=`1. L\xf6gmanns\xfe\xf3knun \xe1n VSK (VSK-skyldur umbj.): kr. ${y.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld \xe1n VSK:     kr. ${v.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0 (\xc1N VSK):         kr. ${N.toLocaleString("is-IS")}
  (Umbj\xf3\xf0andi n\xfdtir innskatt skv. 130. gr. laga nr. 91/1991 og laga nr. 50/1988)

`:R+=`1. L\xf6gmanns\xfe\xf3knun m\xe1lflytjanda m. VSK:        kr. ${x.legalFeeIncVat.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld:            kr. ${x.totalExpensesIncVat.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0:                  kr. ${N.toLocaleString("is-IS")} m. VSK

`,$&&(R+=`${l||"\xdeess er krafist a\xf0 gagna\xf0ili ver\xf0i d\xe6mdur til a\xf0 grei\xf0a m\xe1lskostna\xf0 \xfeennan\nme\xf0 dr\xe1ttarv\xf6xtum samkv\xe6mt 1. mgr. 6. gr. laga nr. 38/2001 um vexti og\nver\xf0tryggingu fr\xe1 \xfeeim degi sem li\xf0inn er m\xe1nu\xf0ur fr\xe1 uppkva\xf0ningu d\xf3ms\ntil grei\xf0sludags."}

`),d&&(R+=`IV. ATHUGASEMDIR:
${d}

`),R+=`Vir\xf0ingarfyllst,
${m}
f.h. ${I} (${p})
${c}
`}}};var t=require("../../../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[276,972,672],()=>a(1480));module.exports=r})();