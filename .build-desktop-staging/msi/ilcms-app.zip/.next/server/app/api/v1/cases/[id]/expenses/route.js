"use strict";(()=>{var e={};e.id=52,e.ids=[52],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3158:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>S,patchFetch:()=>k,requestAsyncStorage:()=>p,routeModule:()=>g,serverHooks:()=>m,staticGenerationAsyncStorage:()=>f});var a={};r.r(a),r.d(a,{DELETE:()=>c,GET:()=>u,POST:()=>d});var n=r(9303),s=r(8716),i=r(670),o=r(7070),l=r(4672),x=r(7616);async function u(e,{params:t}){try{let{id:e}=await t,r=l.gp.filter(t=>t.case_id===e);return o.NextResponse.json({expenses:r})}catch(e){return console.error("Error fetching expenses:",e),o.NextResponse.json({error:"Gat ekki s\xf3tt \xfatlag\xf0an kostna\xf0: "+e?.message},{status:500})}}async function d(e,{params:t}){try{let{id:r}=await t,{expense_type:a,title:n,amount:s,vat_rate:i,incurred_date:u,receipt_doc_title:d}=await e.json();if(!n||null==s)return o.NextResponse.json({error:"Heiti og fj\xe1rh\xe6\xf0 eru nau\xf0synlegir reitir."},{status:400});let c=Number(s),g="court_fee"===a?0:void 0!==i?Number(i):.24,p={id:`exp-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,case_id:r,expense_type:a||"other",title:n.trim(),amount:c,vat_rate:g,vat_amount:Math.round(c*g),incurred_date:u||new Date().toISOString().split("T")[0],receipt_doc_title:d?.trim()||void 0,status:"unbilled",created_at:new Date().toISOString()};l.gp.push(p);let f=l.zo.filter(e=>e.case_id===r),m=l.gp.filter(e=>e.case_id===r),S=(0,x.T)(f,m);return o.NextResponse.json({success:!0,item:p,summary:S})}catch(e){return console.error("Error creating expense:",e),o.NextResponse.json({error:"Gat ekki skr\xe1\xf0 kostna\xf0arli\xf0: "+e?.message},{status:500})}}async function c(e,{params:t}){try{let{id:r}=await t,{searchParams:a}=new URL(e.url),n=a.get("expenseId");if(!n)return o.NextResponse.json({error:"expenseId vantar."},{status:400});let s=l.gp.findIndex(e=>e.id===n&&e.case_id===r);if(-1===s)return o.NextResponse.json({error:"Kostna\xf0arli\xf0ur fannst ekki."},{status:404});l.gp.splice(s,1);let i=l.zo.filter(e=>e.case_id===r),u=l.gp.filter(e=>e.case_id===r),d=(0,x.T)(i,u);return o.NextResponse.json({success:!0,summary:d})}catch(e){return console.error("Error deleting expense:",e),o.NextResponse.json({error:"Gat ekki eytt kostna\xf0arli\xf0: "+e?.message},{status:500})}}let g=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/v1/cases/[id]/expenses/route",pathname:"/api/v1/cases/[id]/expenses",filename:"route",bundlePath:"app/api/v1/cases/[id]/expenses/route"},resolvedPagePath:"/app/applet/src/app/api/v1/cases/[id]/expenses/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:p,staticGenerationAsyncStorage:f,serverHooks:m}=g,S="/api/v1/cases/[id]/expenses/route";function k(){return(0,i.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:f})}},7616:(e,t,r)=>{r.d(t,{T:()=>n,x:()=>s});var a=r(4672);function n(e,t){let r=0,a=0,n=0;e.forEach(e=>{if(r+=e.duration_minutes,e.is_billable){a+=e.duration_minutes;let t=e.duration_minutes/60;n+=Math.round(t*e.hourly_rate)}});let s=Math.round(.24*n),i=n+s,o=0,l=0,x=0;t.forEach(e=>{"court_fee"===e.expense_type?o+=e.amount:(l+=e.amount,x+=e.vat_amount||(e.vat_rate?Math.round(e.amount*e.vat_rate):0))});let u=o+l+x;return{totalMinutes:r,totalHours:Number((r/60).toFixed(2)),billableMinutes:a,billableHours:Number((a/60).toFixed(2)),legalFeeExVat:n,legalFeeVat:s,legalFeeIncVat:i,courtFees:o,otherExpensesExVat:l,otherExpensesVat:x,totalExpensesIncVat:u,grandTotalClaim:i+u,vatRate:.24}}function s(e,t,r,s="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",i){let o,l,x;let u=n(t,r),d=new Date().toLocaleDateString("is-IS",{year:"numeric",month:"long",day:"numeric"}),c="=".repeat(78),g="-".repeat(78),p="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",f="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",m=i,S="Stefnandi",k=!1,$=!0;"object"==typeof s&&null!==s?(s.attorneyName&&(p=`${s.attorneyName}${s.attorneyTitle?` ${s.attorneyTitle}`:""}`),s.courtName&&(f=s.courtName),s.judgeName&&(o=s.judgeName),s.partyName&&(m=s.partyName),s.partyRole&&(S=s.partyRole),void 0!==s.clientVatDeductible&&(k=s.clientVatDeductible),void 0!==s.includeInterestClaim&&($=s.includeInterestClaim),s.interestText&&(l=s.interestText),s.additionalRemarks&&(x=s.additionalRemarks)):"string"==typeof s&&(p=s);let I=m||(e.title.includes(" gegn ")?e.title.split(" gegn ")[0]:"Stefnandi"),L=k?u.legalFeeExVat:u.legalFeeIncVat,N=k?u.courtFees+u.otherExpensesExVat:u.totalExpensesIncVat,R=L+N,v="";v+=`${c}
                M\xc1LSKOSTNA\xd0ARYFIRLIT FYRIR H\xc9RA\xd0SD\xd3MI
               (skv. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la)
${c}

D\xf3mst\xf3ll:      ${f}${o?` (D\xf3mari: ${o})`:""}
M\xe1lsn\xfamer:     ${e.case_number}
M\xe1lsa\xf0ilar:    ${e.title}
A\xf0ili:         ${I} (${S})
M\xe1lflytjandi:  ${p}
Dagsetning:    ${d}

${g}
I. SUNDURLI\xd0UN \xc1 L\xd6GMANNS\xde\xd3KNUN (VINNUSTUNDIR)
${g}
DAGS.        KLST.  T\xcdMAGJALD    VERK\xde\xc1TTUR OG L\xddSING \xc1 L\xd6GFR\xc6\xd0IST\xd6RFUM
${g}
`;let y=t.filter(e=>e.is_billable);return 0===y.length?v+=`Engir t\xedmali\xf0ir skr\xe1\xf0ir.
`:y.forEach(e=>{let t=(e.duration_minutes/60).toFixed(1).padStart(4," "),r=`${e.hourly_rate.toLocaleString("is-IS")} kr.`.padStart(11," "),n=a.lf[e.task_category]||e.task_category;v+=`${e.date}  ${t}  ${r}  [${n}]
                          ${e.description} (${e.user_name})
`}),v+=`
${g}
Samtals unnar stundir m\xe1lflytjanda:       ${u.billableHours.toLocaleString("is-IS")} klst.
L\xf6gmanns\xfe\xf3knun alls \xe1n VSK:               kr. ${u.legalFeeExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur (24% VSK):              kr. ${u.legalFeeVat.toLocaleString("is-IS")}
L\xd6GMANNS\xde\xd3KNUN SAMTALS M. VSK:            kr. ${u.legalFeeIncVat.toLocaleString("is-IS")}

${g}
II. \xdaTLAG\xd0UR KOSTNA\xd0UR OG D\xd3MGJ\xd6LD
${g}
DAGS.        UPPH\xc6\xd0         LI\xd0UR / TEGUND
${g}
`,0===r.length?v+=`Enginn \xfatlag\xf0ur kostna\xf0ur skr\xe1\xf0ur.
`:r.forEach(e=>{let t=a.v6[e.expense_type]||e.expense_type,r=e.amount+(e.vat_amount||0),n=`${r.toLocaleString("is-IS")} kr.`.padStart(12," ");v+=`${e.incurred_date}  ${n}  ${e.title} (${t})
`}),v+=`
${g}
D\xf3mgj\xf6ld skv. l\xf6gum nr. 88/1991 (0% VSK):  kr. ${u.courtFees.toLocaleString("is-IS")}
Annar \xfatlag\xf0ur kostna\xf0ur \xe1n VSK:          kr. ${u.otherExpensesExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur af \xfatl\xf6g\xf0um kostna\xf0i:   kr. ${u.otherExpensesVat.toLocaleString("is-IS")}
\xdaTLAG\xd0UR KOSTNA\xd0UR SAMTALS:               kr. ${u.totalExpensesIncVat.toLocaleString("is-IS")}

${c}
III. HEILDARKRAFA UM M\xc1LSKOSTNA\xd0
${c}
`,k?v+=`1. L\xf6gmanns\xfe\xf3knun \xe1n VSK (VSK-skyldur umbj.): kr. ${L.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld \xe1n VSK:     kr. ${N.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0 (\xc1N VSK):         kr. ${R.toLocaleString("is-IS")}
  (Umbj\xf3\xf0andi n\xfdtir innskatt skv. 130. gr. laga nr. 91/1991 og laga nr. 50/1988)

`:v+=`1. L\xf6gmanns\xfe\xf3knun m\xe1lflytjanda m. VSK:        kr. ${u.legalFeeIncVat.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld:            kr. ${u.totalExpensesIncVat.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0:                  kr. ${R.toLocaleString("is-IS")} m. VSK

`,$&&(v+=`${l||"\xdeess er krafist a\xf0 gagna\xf0ili ver\xf0i d\xe6mdur til a\xf0 grei\xf0a m\xe1lskostna\xf0 \xfeennan\nme\xf0 dr\xe1ttarv\xf6xtum samkv\xe6mt 1. mgr. 6. gr. laga nr. 38/2001 um vexti og\nver\xf0tryggingu fr\xe1 \xfeeim degi sem li\xf0inn er m\xe1nu\xf0ur fr\xe1 uppkva\xf0ningu d\xf3ms\ntil grei\xf0sludags."}

`),x&&(v+=`IV. ATHUGASEMDIR:
${x}

`),v+=`Vir\xf0ingarfyllst,
${p}
f.h. ${I} (${S})
${c}
`}}};var t=require("../../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[276,972,672],()=>r(3158));module.exports=a})();