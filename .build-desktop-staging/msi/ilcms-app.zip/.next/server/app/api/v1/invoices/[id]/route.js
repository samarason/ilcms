"use strict";(()=>{var e={};e.id=630,e.ids=[630],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},7282:(e,t,n)=>{n.r(t),n.d(t,{originalPathname:()=>_,patchFetch:()=>m,requestAsyncStorage:()=>g,routeModule:()=>p,serverHooks:()=>f,staticGenerationAsyncStorage:()=>x});var i={};n.r(i),n.d(i,{GET:()=>l,PATCH:()=>c});var r=n(9303),a=n(8716),s=n(670),d=n(7070),o=n(4672),u=n(2276);async function l(e,{params:t}){try{let{id:e}=await t,n=o.bn.find(t=>t.id===e||t.invoice_number===e);if(!n)return d.NextResponse.json({error:"Reikningur fannst ekki."},{status:404});let i=(0,u.t)(n);return d.NextResponse.json({success:!0,invoice:n,formatted_text:i})}catch(e){return console.error("Error fetching invoice:",e),d.NextResponse.json({error:"Gat ekki s\xf3tt reikning: "+e?.message},{status:500})}}async function c(e,{params:t}){try{let{id:n}=await t,i=o.bn.find(e=>e.id===n||e.invoice_number===n);if(!i)return d.NextResponse.json({error:"Reikningur fannst ekki."},{status:404});let r=await e.json();if(r.status){if(!["draft","issued","paid","cancelled"].includes(r.status))return d.NextResponse.json({error:"\xd3gild sta\xf0a reiknings."},{status:400});if(i.status=r.status,"paid"===r.status&&(i.payment_date=r.payment_date||new Date().toISOString().split("T")[0],i.payment_reference=r.payment_reference||"Grei\xf0sla m\xf3ttekin"),"cancelled"===r.status){let e=i.line_items.filter(e=>"time"===e.type&&e.ref_id).map(e=>e.ref_id);for(let t of o.zo)e.includes(t.id)&&(t.status="unbilled");let t=i.line_items.filter(e=>"expense"===e.type&&e.ref_id).map(e=>e.ref_id);for(let e of o.gp)t.includes(e.id)&&(e.status="unbilled");i.retainer_deducted>0&&o._z.unshift({id:`ret-rev-${Date.now()}`,case_id:i.case_id,type:"deposit",amount:i.retainer_deducted,date:new Date().toISOString().split("T")[0],payment_method:"bank_transfer",reference:`Bakf\xe6rsla vegna ni\xf0urfellds reiknings ${i.invoice_number}`,notes:`Bakf\xe6rt tryggingaf\xe9 vegna \xf3gildingar reiknings nr. ${i.invoice_number}.`,created_at:new Date().toISOString()})}}return void 0!==r.notes&&(i.notes=r.notes),d.NextResponse.json({success:!0,message:"Reikningur var uppf\xe6r\xf0ur.",invoice:i})}catch(e){return console.error("Error updating invoice:",e),d.NextResponse.json({error:"Gat ekki uppf\xe6rt reikning: "+e?.message},{status:500})}}let p=new r.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/v1/invoices/[id]/route",pathname:"/api/v1/invoices/[id]",filename:"route",bundlePath:"app/api/v1/invoices/[id]/route"},resolvedPagePath:"/app/applet/src/app/api/v1/invoices/[id]/route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:g,staticGenerationAsyncStorage:x,serverHooks:f}=p,_="/api/v1/invoices/[id]/route";function m(){return(0,s.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:x})}},2276:(e,t,n)=>{n.d(t,{t:()=>i});function i(e){let t="=".repeat(78),n="-".repeat(78),i={draft:"DR\xd6G",issued:"\xdaTGEFI\xd0",paid:"GREITT",cancelled:"\xd3GILT / FELLT NI\xd0UR"}[e.status]||e.status.toUpperCase(),r="";return r+=`${t}
                          REIKNINGUR / INVOICE
                           [ ${i} ]
${t}

\xdaTGEFANDI (L\xd6GMANNSSTOFA):
Nafn:          ${e.law_firm_name||"L\xf6gmenn L\xe6kjarg\xf6tu slf."}
Kennitala:     ${e.law_firm_kennitala||"540209-1120"}
VSK-n\xfamer:     ${e.law_firm_vat_no||"102345"}
M\xe1lflytjandi:  ${e.attorney_name||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl."}
Bankareikn.:   ${e.law_firm_bank||"0101-26-045678"}

GREI\xd0ANDI (UMBJ\xd3\xd0ANDI):
Nafn:          ${e.client_name}
`,e.client_kennitala&&(r+=`Kennitala:     ${e.client_kennitala}
`),e.client_address&&(r+=`Heimilisfang:  ${e.client_address}
`),r+=`M\xe1lsn\xfamer:     ${e.case_number} - ${e.case_title}

REIKNINGSUPPL\xddSINGAR:
Reikningsnr.:  ${e.invoice_number}
\xdatg\xe1fudagur:   ${e.issue_date}
Gjalddagi:     ${e.due_date}
Eindagi:       ${e.penalty_date}
`,e.payment_date&&(r+=`Grei\xf0sludagur: ${e.payment_date} (${e.payment_reference||"Grei\xf0sla m\xf3ttekin"})
`),r+=`
${n}
SUNDURLI\xd0UN REIKNINGS
${n}
L\xddSING / VERK\xde\xc1TTUR                  MAGN     EIN.VER\xd0     VSK%    SAMTALS M. VSK
${n}
`,e.line_items&&0!==e.line_items.length?e.line_items.forEach((e,t)=>{let n=String(t+1).padStart(2," "),i=e.description.length>34?e.description.slice(0,31)+"...":e.description.padEnd(34," "),a=e.quantity.toFixed(1).padStart(5," "),s=`${e.unit_price.toLocaleString("is-IS")} kr.`.padStart(11," "),d=`${Math.round(100*e.vat_rate)}%`.padStart(5," "),o=`${e.total_inc_vat.toLocaleString("is-IS")} kr.`.padStart(14," ");r+=`${n}. ${i} ${a} ${s} ${d} ${o}
`}):r+=`Engir li\xf0ir \xe1 reikningi.
`,r+=`${n}
Samtals \xe1n vir\xf0isaukaskatts:                              kr. ${e.subtotal_ex_vat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur samtals (24% / 0% VSK):                 kr. ${e.total_vat.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARFJ\xc1RH\xc6\xd0 M. VSK:                                    kr. ${e.total_inc_vat.toLocaleString("is-IS")}
`,e.retainer_deducted>0&&(r+=`Fr\xe1dr\xe1ttur af tryggingaf\xe9 (v\xf6rslureikningi):            - kr. ${e.retainer_deducted.toLocaleString("is-IS")}
------------------------------------------------------------------------------
EFTIRST\xd6\xd0VAR TIL GREI\xd0SLU:                                kr. ${e.final_amount_due.toLocaleString("is-IS")}
`),e.notes&&(r+=`
Athugasemdir:
${e.notes}
`),r+=`
${t}
GREI\xd0SLUSKILM\xc1LAR:
Vinsamlegast leggi\xf0 inn \xe1 ofangreindan reikning og tilgreini\xf0 reikningsn\xfamer sem tilv\xedsun.
S\xe9 reikningur ekki greiddur \xe1 eindaga reiknast h\xe6stu l\xf6gleyf\xf0u dr\xe1ttarvextir
samkv\xe6mt 1. mgr. 6. gr. laga nr. 38/2001 um vexti og ver\xf0tryggingu fr\xe1 gjalddaga.
${t}
`}}};var t=require("../../../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),i=t.X(0,[276,972,672],()=>n(7282));module.exports=i})();