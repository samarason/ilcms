"use strict";(()=>{var e={};e.id=23,e.ids=[23],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2358:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>p,patchFetch:()=>k,requestAsyncStorage:()=>m,routeModule:()=>g,serverHooks:()=>S,staticGenerationAsyncStorage:()=>f});var a={};r.r(a),r.d(a,{DELETE:()=>c,GET:()=>x,POST:()=>d});var n=r(9303),i=r(8716),s=r(670),o=r(7070),l=r(4672),u=r(7616);async function x(e,{params:t}){try{let{id:e}=await t,r=l.zo.filter(t=>t.case_id===e),a=l.gp.filter(t=>t.case_id===e),n=(0,u.T)(r,a);return o.NextResponse.json({time_entries:r,summary:n})}catch(e){return console.error("Error fetching time entries:",e),o.NextResponse.json({error:"Gat ekki s\xf3tt t\xedmali\xf0i: "+e?.message},{status:500})}}async function d(e,{params:t}){try{let{id:r}=await t,{date:a,duration_minutes:n,hourly_rate:i,task_category:s,description:x,is_billable:d,user_name:c,user_role:g}=await e.json();if(!x||!n)return o.NextResponse.json({error:"L\xfdsing og t\xedmalengd \xed m\xedn\xfatum eru nau\xf0synlegir reitir."},{status:400});let m={id:`time-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,case_id:r,user_id:"usr-lawyer-01",user_name:c||"Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",user_role:g||"M\xe1lflytjandi / Partner",date:a||new Date().toISOString().split("T")[0],duration_minutes:Number(n),hourly_rate:Number(i)||36e3,task_category:s||"pleading",description:x.trim(),is_billable:!1!==d,status:"unbilled",created_at:new Date().toISOString()};l.zo.push(m);let f=l.zo.filter(e=>e.case_id===r),S=l.gp.filter(e=>e.case_id===r),p=(0,u.T)(f,S);return o.NextResponse.json({success:!0,item:m,summary:p})}catch(e){return console.error("Error creating time entry:",e),o.NextResponse.json({error:"Gat ekki skr\xe1\xf0 t\xedmali\xf0: "+e?.message},{status:500})}}async function c(e,{params:t}){try{let{id:r}=await t,{searchParams:a}=new URL(e.url),n=a.get("entryId");if(!n)return o.NextResponse.json({error:"entryId vantar."},{status:400});let i=l.zo.findIndex(e=>e.id===n&&e.case_id===r);if(-1===i)return o.NextResponse.json({error:"T\xedmali\xf0ur fannst ekki."},{status:404});l.zo.splice(i,1);let s=l.zo.filter(e=>e.case_id===r),x=l.gp.filter(e=>e.case_id===r),d=(0,u.T)(s,x);return o.NextResponse.json({success:!0,summary:d})}catch(e){return console.error("Error deleting time entry:",e),o.NextResponse.json({error:"Gat ekki eytt t\xedmali\xf0: "+e?.message},{status:500})}}let g=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/v1/cases/[id]/time-entries/route",pathname:"/api/v1/cases/[id]/time-entries",filename:"route",bundlePath:"app/api/v1/cases/[id]/time-entries/route"},resolvedPagePath:"/app/applet/src/app/api/v1/cases/[id]/time-entries/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:f,serverHooks:S}=g,p="/api/v1/cases/[id]/time-entries/route";function k(){return(0,s.patchFetch)({serverHooks:S,staticGenerationAsyncStorage:f})}},7616:(e,t,r)=>{r.d(t,{T:()=>n,x:()=>i});var a=r(4672);function n(e,t){let r=0,a=0,n=0;e.forEach(e=>{if(r+=e.duration_minutes,e.is_billable){a+=e.duration_minutes;let t=e.duration_minutes/60;n+=Math.round(t*e.hourly_rate)}});let i=Math.round(.24*n),s=n+i,o=0,l=0,u=0;t.forEach(e=>{"court_fee"===e.expense_type?o+=e.amount:(l+=e.amount,u+=e.vat_amount||(e.vat_rate?Math.round(e.amount*e.vat_rate):0))});let x=o+l+u;return{totalMinutes:r,totalHours:Number((r/60).toFixed(2)),billableMinutes:a,billableHours:Number((a/60).toFixed(2)),legalFeeExVat:n,legalFeeVat:i,legalFeeIncVat:s,courtFees:o,otherExpensesExVat:l,otherExpensesVat:u,totalExpensesIncVat:x,grandTotalClaim:s+x,vatRate:.24}}function i(e,t,r,i="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",s){let o,l,u;let x=n(t,r),d=new Date().toLocaleDateString("is-IS",{year:"numeric",month:"long",day:"numeric"}),c="=".repeat(78),g="-".repeat(78),m="Gu\xf0r\xfan Sigur\xf0ard\xf3ttir hrl.",f="H\xe9ra\xf0sd\xf3mur Reykjav\xedkur",S=s,p="Stefnandi",k=!1,$=!0;"object"==typeof i&&null!==i?(i.attorneyName&&(m=`${i.attorneyName}${i.attorneyTitle?` ${i.attorneyTitle}`:""}`),i.courtName&&(f=i.courtName),i.judgeName&&(o=i.judgeName),i.partyName&&(S=i.partyName),i.partyRole&&(p=i.partyRole),void 0!==i.clientVatDeductible&&(k=i.clientVatDeductible),void 0!==i.includeInterestClaim&&($=i.includeInterestClaim),i.interestText&&(l=i.interestText),i.additionalRemarks&&(u=i.additionalRemarks)):"string"==typeof i&&(m=i);let I=S||(e.title.includes(" gegn ")?e.title.split(" gegn ")[0]:"Stefnandi"),y=k?x.legalFeeExVat:x.legalFeeIncVat,L=k?x.courtFees+x.otherExpensesExVat:x.totalExpensesIncVat,N=y+L,R="";R+=`${c}
                M\xc1LSKOSTNA\xd0ARYFIRLIT FYRIR H\xc9RA\xd0SD\xd3MI
               (skv. 130. gr. laga nr. 91/1991 um me\xf0fer\xf0 einkam\xe1la)
${c}

D\xf3mst\xf3ll:      ${f}${o?` (D\xf3mari: ${o})`:""}
M\xe1lsn\xfamer:     ${e.case_number}
M\xe1lsa\xf0ilar:    ${e.title}
A\xf0ili:         ${I} (${p})
M\xe1lflytjandi:  ${m}
Dagsetning:    ${d}

${g}
I. SUNDURLI\xd0UN \xc1 L\xd6GMANNS\xde\xd3KNUN (VINNUSTUNDIR)
${g}
DAGS.        KLST.  T\xcdMAGJALD    VERK\xde\xc1TTUR OG L\xddSING \xc1 L\xd6GFR\xc6\xd0IST\xd6RFUM
${g}
`;let _=t.filter(e=>e.is_billable);return 0===_.length?R+=`Engir t\xedmali\xf0ir skr\xe1\xf0ir.
`:_.forEach(e=>{let t=(e.duration_minutes/60).toFixed(1).padStart(4," "),r=`${e.hourly_rate.toLocaleString("is-IS")} kr.`.padStart(11," "),n=a.lf[e.task_category]||e.task_category;R+=`${e.date}  ${t}  ${r}  [${n}]
                          ${e.description} (${e.user_name})
`}),R+=`
${g}
Samtals unnar stundir m\xe1lflytjanda:       ${x.billableHours.toLocaleString("is-IS")} klst.
L\xf6gmanns\xfe\xf3knun alls \xe1n VSK:               kr. ${x.legalFeeExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur (24% VSK):              kr. ${x.legalFeeVat.toLocaleString("is-IS")}
L\xd6GMANNS\xde\xd3KNUN SAMTALS M. VSK:            kr. ${x.legalFeeIncVat.toLocaleString("is-IS")}

${g}
II. \xdaTLAG\xd0UR KOSTNA\xd0UR OG D\xd3MGJ\xd6LD
${g}
DAGS.        UPPH\xc6\xd0         LI\xd0UR / TEGUND
${g}
`,0===r.length?R+=`Enginn \xfatlag\xf0ur kostna\xf0ur skr\xe1\xf0ur.
`:r.forEach(e=>{let t=a.v6[e.expense_type]||e.expense_type,r=e.amount+(e.vat_amount||0),n=`${r.toLocaleString("is-IS")} kr.`.padStart(12," ");R+=`${e.incurred_date}  ${n}  ${e.title} (${t})
`}),R+=`
${g}
D\xf3mgj\xf6ld skv. l\xf6gum nr. 88/1991 (0% VSK):  kr. ${x.courtFees.toLocaleString("is-IS")}
Annar \xfatlag\xf0ur kostna\xf0ur \xe1n VSK:          kr. ${x.otherExpensesExVat.toLocaleString("is-IS")}
Vir\xf0isaukaskattur af \xfatl\xf6g\xf0um kostna\xf0i:   kr. ${x.otherExpensesVat.toLocaleString("is-IS")}
\xdaTLAG\xd0UR KOSTNA\xd0UR SAMTALS:               kr. ${x.totalExpensesIncVat.toLocaleString("is-IS")}

${c}
III. HEILDARKRAFA UM M\xc1LSKOSTNA\xd0
${c}
`,k?R+=`1. L\xf6gmanns\xfe\xf3knun \xe1n VSK (VSK-skyldur umbj.): kr. ${y.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld \xe1n VSK:     kr. ${L.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0 (\xc1N VSK):         kr. ${N.toLocaleString("is-IS")}
  (Umbj\xf3\xf0andi n\xfdtir innskatt skv. 130. gr. laga nr. 91/1991 og laga nr. 50/1988)

`:R+=`1. L\xf6gmanns\xfe\xf3knun m\xe1lflytjanda m. VSK:        kr. ${x.legalFeeIncVat.toLocaleString("is-IS")}
2. \xdatlag\xf0ur kostna\xf0ur og d\xf3mgj\xf6ld:            kr. ${x.totalExpensesIncVat.toLocaleString("is-IS")}
------------------------------------------------------------------------------
HEILDARKRAFA UM M\xc1LSKOSTNA\xd0:                  kr. ${N.toLocaleString("is-IS")} m. VSK

`,$&&(R+=`${l||"\xdeess er krafist a\xf0 gagna\xf0ili ver\xf0i d\xe6mdur til a\xf0 grei\xf0a m\xe1lskostna\xf0 \xfeennan\nme\xf0 dr\xe1ttarv\xf6xtum samkv\xe6mt 1. mgr. 6. gr. laga nr. 38/2001 um vexti og\nver\xf0tryggingu fr\xe1 \xfeeim degi sem li\xf0inn er m\xe1nu\xf0ur fr\xe1 uppkva\xf0ningu d\xf3ms\ntil grei\xf0sludags."}

`),u&&(R+=`IV. ATHUGASEMDIR:
${u}

`),R+=`Vir\xf0ingarfyllst,
${m}
f.h. ${I} (${p})
${c}
`}}};var t=require("../../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[276,972,672],()=>r(2358));module.exports=a})();